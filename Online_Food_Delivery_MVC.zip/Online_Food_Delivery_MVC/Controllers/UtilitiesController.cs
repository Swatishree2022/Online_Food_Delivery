﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class UtilitiesController : Controller
    {
        // GET: UtitlitiesController
        public ActionResult Index()
        {
            return View();
        }

        // GET: UtitlitiesController/Details/5
        public ActionResult GetUtilitiesDetails(int id)
        {
            return View();
        }

        // GET: UtitlitiesController/Create
        public ActionResult AddUtilitiesDetails()
        {
            return View();
        }

        // POST: UtitlitiesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddUtilitiesDetails(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UtitlitiesController/Edit/5
        public ActionResult UpdateUtilitiesDetails(int id)
        {
            return View();
        }

        // POST: UtitlitiesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateUtilitiesDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: UtitlitiesController/Delete/5
        public ActionResult DeleteUtilitiesDetails(int id)
        {
            return View();
        }

        // POST: UtitlitiesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteUtilitiesDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
