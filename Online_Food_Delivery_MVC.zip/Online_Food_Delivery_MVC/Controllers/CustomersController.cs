﻿using DNTCaptcha.Core;
using DNTCaptcha.Core.Providers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Net.Http.Json;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class CustomersController : Controller
    {
        public readonly IDNTCaptchaValidatorService _validatorService;

        private readonly HttpClient _httpClient;
        public CustomersController(HttpClient httpClient, IDNTCaptchaValidatorService validatorService)
        {
            _httpClient = httpClient;
            _validatorService = validatorService;
        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Customers");
            if (response.IsSuccessStatusCode)
            {


                var jsondata = await response.Content.ReadAsStringAsync();
                var customer = JsonConvert.DeserializeObject<List<Customer>>(jsondata);
                return View(customer);
            }
            return View();
        }

        // GET: CustomersController/Details/5
        public async Task<IActionResult> GetCustomerDetails(int? id)
        {

            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Customers/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var user = JsonConvert.DeserializeObject<Customer>(jsondata);
                return View(user);
            }
            return NotFound();
        }

        // GET: CustomersController/Create
        public ActionResult AddCustomerDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddCustomerDetails(CustomerLoginViewModel model)
        {
            if (!_validatorService.HasRequestValidCaptchaEntry(Language.English, DisplayMode.ShowDigits))
            {

                this.ModelState.AddModelError(DNTCaptchaTagHelper.CaptchaInputName, "Please Enter Valid Captcha.");

            }
            else
            {
                var response1 = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Customers", model.Customer);
                model.Login.LoginType = "C";
                var response2 = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Login", model.Login);
                return RedirectToAction(nameof(Login), "Logins");
            }
            return View(model);
        }

        // GET: CustomersController/Edit/5
        public async Task<IActionResult> UpdateCustomerDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Customers/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var customer = JsonConvert.DeserializeObject<Customer>(jsondata);
                return View(customer);
            }
            return View();
        }
        // POST: CustomersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateCustomerDetails(int id, Customer customer)
        {
            if (id != customer.CustomerId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(customer);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Customers/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(customer);
        }

      


        // POST: CustomersController/Delete/5
    
        public async Task<IActionResult> DeleteCustomerDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Customers/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var cust = JsonConvert.DeserializeObject<Customer>(jsondata);
                return View(cust);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteCustomerDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Customers/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
    }
    

