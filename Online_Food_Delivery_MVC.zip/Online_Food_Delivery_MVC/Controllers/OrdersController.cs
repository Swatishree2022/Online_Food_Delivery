﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class OrdersController : Controller
    {
        private readonly HttpClient _httpClient;
        public OrdersController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Orders");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<List<Order>>(jsondata);
                return View(order);
            }
            return View();
        }
        public async Task<IActionResult> OrderList()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Orders");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<List<Order>>(jsondata);
                return View(order);
            }
            return View();
        }
        // GET: OrdersController/Details/5
        public async Task<IActionResult> GetOrderDetails(int? id)
        {

            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<Order>(jsondata);
                return View(order);
            }
            return NotFound();
        }
        // GET: AdminsController/Create
        public ActionResult AddOrderDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrderDetails(Order order)
        {
            
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Orders", order);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateOrderDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<Order>(jsondata);
                return View(order);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateOrderDetails(int id, Order order)
        {
            if (id != order.OrderId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(order);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Orders/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(order);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5

        public async Task<IActionResult> DeleteOrderDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<Order>(jsondata);
                return View(order);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteOrderDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }

    }
}
