﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class RestaurantsController : Controller
    {
      
            private readonly HttpClient _httpClient;
            public RestaurantsController(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Restaurants");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var restaurant = JsonConvert.DeserializeObject<List<Restaurant>>(jsondata);
                return View(restaurant);
            }
            return View();
        }
        public async Task<IActionResult> AdminDefault()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Restaurants");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var restaurant = JsonConvert.DeserializeObject<List<Restaurant>>(jsondata);
                return View(restaurant);
            }
            return View();
        }
        // GET: RestaurantsController/Details/5
        public async Task<IActionResult> GetRestaurantDetails(int? id)
        {

            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Restaurants/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var restaurant = JsonConvert.DeserializeObject<Restaurant>(jsondata);
                return View(restaurant);
            }
            return NotFound();
        }
        // GET: AdminsController/Create
        public ActionResult AddRestaurantDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddRestaurantDetails(Restaurant restaurant)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Restaurants", restaurant);
            return RedirectToAction(nameof(AdminDefault));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateRestaurantDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Restaurants/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var restaurant = JsonConvert.DeserializeObject<Restaurant>(jsondata);
                return View(restaurant);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateRestaurantDetails(int id, Restaurant restaurant)
        {
            if (id != restaurant.RestaurantId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(restaurant);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Restaurants/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(restaurant);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5

        public async Task<IActionResult> DeleteRestaurantDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Restaurants/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var restaurant = JsonConvert.DeserializeObject<Restaurant>(jsondata);
                return View(restaurant);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteRestaurantDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Restaurants/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
