﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class AdminsController : Controller
    {
        private readonly HttpClient _httpClient;
        public AdminsController (HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Admins");
        if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<List<Admin>>(jsondata);
                return View(admin);
            }
            return View();
        }

        // GET: AdminsController/Details/5
      

        public async Task<IActionResult> GetAdminDetails(int? id)
        {
           
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var user = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(user);
            }
            return NotFound();
        }
        // GET: AdminsController/Create
        public ActionResult AddAdminDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminDetails(Admin admin)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Admins", admin);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5
       
        public async Task<IActionResult> UpdateAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminDetails(int id, Admin admin)
        {
            if (id != admin.AdminId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(admin);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Admins/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(admin);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
  
        public async Task<IActionResult> DeleteAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var user = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(user);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
