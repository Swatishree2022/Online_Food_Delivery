﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using DNTCaptcha.Core;
using DNTCaptcha.Core.Providers;

using Online_Food_Delivery_DAO;
using DNTCaptcha.Core.Contracts;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class LoginsController : Controller
    {
        private readonly HttpClient _httpClient;


        public readonly IDNTCaptchaValidatorService _validatorService;

        public LoginsController(IDNTCaptchaValidatorService validatorService, HttpClient httpClient)

        {
            _httpClient = httpClient;
            _validatorService = validatorService;

        }

        public ActionResult Login()
        {
            return View();
        }
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateDNTCaptcha(ErrorMessage = "Please Enter Valid Captcha",
            CaptchaGeneratorLanguage = Language.English,
            CaptchaGeneratorDisplayMode = DisplayMode.ShowDigits)]

        public async Task<IActionResult> Login(string username, string password)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Login/{username}/{password}");
            if (response.IsSuccessStatusCode)
            {
                if (ModelState.IsValid)
                {
                    if (!_validatorService.HasRequestValidCaptchaEntry(Language.English, DisplayMode.ShowDigits))
                    {
                        this.ModelState.AddModelError(DNTCaptchaTagHelper.CaptchaInputName, "Please Enter Valid Captcha.");
                    }
                    else
                    {
                        var logintype = await response.Content.ReadAsStringAsync();
                       

                        if (logintype == "")
                        {
                            return View();
                        }
                        else if (logintype == "C")
                        {
                            return RedirectToAction("Master", "Home");
                        }
                        else if (logintype == "A")
                        {
                            return RedirectToAction(nameof(Default), "Admins");
                        }
                        else
                        {
                           return RedirectToAction(nameof(Login),logintype);
                        }
                    }
                }
                return View();

            }
            return View();

        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Logins");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var login = JsonConvert.DeserializeObject<List<Login>>(jsondata);
                return View(login);
            }
            return View();
        }

        // GET: LoginsController/Details/5
        public ActionResult GetLoginDetails(int id)
        {
            return View();
        }

        // GET: LoginsController/Create
        public ActionResult AddLoginDetails()
        {
            return View();
        }

        // POST: LoginsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddLoginDetails(Login login)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Logins", login);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5
        public async Task<IActionResult> UpdateLoginDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Logins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var login = JsonConvert.DeserializeObject<Login>(jsondata);
                return View(login);
            }
            return View();
        }

        public ActionResult Logout()
        {
            //await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction(nameof(Login), "Logins");
        }



        // POST: LoginsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminDetails(Login login)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Logins", login);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5
        public async Task<IActionResult> UpdateAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Logins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var login = JsonConvert.DeserializeObject<Login>(jsondata);
                return View(login);
            }
            return View();
        }
        // POST: LoginsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteLoginDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Default));
            }
            catch
            {
                return View();
            }
        }
        public ActionResult ForgotPassword()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPassword(string username)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Login/{username}");
            ViewBag.Password = username;
            if (response.IsSuccessStatusCode)
            {
                if (ModelState.IsValid)
                {
                    var password = await response.Content.ReadAsStringAsync();
                    if (password == "")
                    {
                        return View();
                    }
                    else
                    {
                        ViewBag.Password = password;
                        return View();
                    }

                }
            }
            return View();

        }

    }
}