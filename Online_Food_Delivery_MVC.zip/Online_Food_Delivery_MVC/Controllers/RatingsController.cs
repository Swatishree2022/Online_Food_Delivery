﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class RatingsController : Controller
    {
        private readonly HttpClient _httpClient;
        public RatingsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Ratings");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var rating = JsonConvert.DeserializeObject<List<Rating>>(jsondata);
                return View(rating);
            }
            return View();
        }
        public async Task<IActionResult> GetRatingDetails(int? id)
        {

            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Ratings/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var rating = JsonConvert.DeserializeObject<Rating>(jsondata);
                return View(rating);
            }
            return NotFound();
        }
        // GET: AdminsController/Create
        public ActionResult AddRatingDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddRatingDetails(Rating rating)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Ratings", rating);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateRatingDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Ratings/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var rating = JsonConvert.DeserializeObject<Rating>(jsondata);
                return View(rating);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateRatingDetails(int id, Rating rating)
        {
            if (id != rating.RatingId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(rating);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Ratings/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(rating);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5

        public async Task<IActionResult> DeleteRatingDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Ratings/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var rating = JsonConvert.DeserializeObject<Rating>(jsondata);
                return View(rating);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteRatingDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Ratings/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
