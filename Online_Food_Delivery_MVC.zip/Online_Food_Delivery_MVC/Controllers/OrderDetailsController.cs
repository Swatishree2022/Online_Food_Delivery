﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{
    public class OrderDetailsController : Controller
    {
        private readonly HttpClient _httpClient;
        public OrderDetailsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/OrderDetails");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var orderdetails = JsonConvert.DeserializeObject<List<OrderDetail>>(jsondata);
                return View(orderdetails);
            }
            return View();
        }

        // GET: OrderDetailsController/Details/5
        public async Task<IActionResult> GetOrderDetailDetails(int? id)
        {

            var response = await _httpClient.GetAsync($"http://localhost:5012/api/OrderDetails/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var orderDetail = JsonConvert.DeserializeObject<OrderDetail>(jsondata);
                return View(orderDetail);
            }
            return NotFound();
        }
        // GET: AdminsController/Create
        public ActionResult AddOrderDetailDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrderDetailDetails(OrderDetail orderDetail)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/OrderDetails", orderDetail);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateOrderDetailDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/OrderDetails/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var orderDetail = JsonConvert.DeserializeObject<OrderDetail>(jsondata);
                return View(orderDetail);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateOrderDetailDetails(int id, OrderDetail orderDetail)
        {
            if (id != orderDetail.OrderDetailId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(orderDetail);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/OrderDetails/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(orderDetail);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5

        public async Task<IActionResult> DeleteOrderDetailDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/OrderDetails/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var orderDetail = JsonConvert.DeserializeObject<OrderDetail>(jsondata);
                return View(orderDetail);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteOrderDetailDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/OrderDetails/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
