﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Online_Food_Delivery_DAO;
using System.Security.Policy;
using System.Text;

namespace Online_Food_Delivery_MVC.Controllers
{

    public class ItemsController : Controller

    {
        
        private readonly HttpClient _httpClient;

        public ItemsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
           
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5012/api/Items");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var item = JsonConvert.DeserializeObject<List<Item>>(jsondata);
                return View(item);
            }
            return View();
        }

        // GET: ItemsController/Details/5
        public async Task<IActionResult> GetItemDetails(int? id)
        {

            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Items/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var item = JsonConvert.DeserializeObject<Item>(jsondata);
                return View(item);
            }
            return NotFound();
        }

        // GET: ItemsController/Create
        public ActionResult AddItemDetails()
        {
            return View();
        }
       

            // POST: ItemsController/Create
            [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddItemDetails(Item item)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5012/api/Items", item);
            return RedirectToAction(nameof(Default));
        }

        // GET: ItemsController/Edit/5

        public async Task<IActionResult> UpdateItemDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Items/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var item = JsonConvert.DeserializeObject<Item>(jsondata);
                return View(item);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateItemDetails(int id, Item item)
        {
            if (id != item.ItemId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(item);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5012/api/Items/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(item);
        }
        // GET: ItemsController/Delete/5


        // POST: ItemsController/Delete/5

        public async Task<IActionResult> DeleteItemDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5012/api/Items/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var item = JsonConvert.DeserializeObject<Item>(jsondata);
                return View(item);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteItemDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5012/api/Items/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(int id)
        {
            var foodItem = await _httpClient.GetFromJsonAsync<Item>($"http://localhost:5012/api/Items/{id}");
            if (foodItem != null)
            {
                var cart = AddItemToOrder();
                cart.Add(foodItem);
                SaveCartItems(cart);
            }
            return RedirectToAction("Default");
        }

        [HttpPost]
        public IActionResult RemoveFromCart(int id)
        {
            var cart = AddItemToOrder();
            var cartItem = cart.FirstOrDefault(c => c.ItemId == id);
            if (cartItem != null)
            {
                cart.Remove(cartItem);
                SaveCartItems(cart);
            }
            return RedirectToAction("Default");
        }

       
        private List<Item> AddItemToOrder()
        {
            // Retrieve cart items from TempData
            var cart = TempData["Cart"] as List<Item>;
            if (cart == null)
            {
                cart = new List<Item>();
            }
            return cart;
        }

        private void SaveCartItems(List<Item> cart)
        {
            // Save cart items to TempData
            TempData["Cart"] = cart;
        }
    }
}



